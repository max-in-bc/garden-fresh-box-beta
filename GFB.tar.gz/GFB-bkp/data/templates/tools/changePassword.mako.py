# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 9
_modified_time = 1425162031.815413
_enable_loop = True
_template_filename = '/home/edgard/eclipse-workspaces/gfb/GFB/gardenfreshbox/templates/tools/changePassword.mako'
_template_uri = '/tools/changePassword.mako'
_source_encoding = 'utf-8'
from webhelpers.html import escape
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(u'<!DOCTYPE html>\n<html lang="en">\n\n<head>\n\t<meta charset="utf-8">\n\t<meta http-equiv="X-UA-Compatible" content="IE=edge">\n\t<meta name="viewport" content="width=device-width, initial-scale=1">\n\t<meta name="description" content="Garden Fresh Box">\n\t<meta name="author" content="Fruitful Community Solutions">\n\n\t<title>Garden Fresh Box</title>\n\n\t<!-- Bootstrap Core CSS -->\n\t<link href="../css/bootstrap.min.css" rel="stylesheet">\n\t<!-- Custom CSS -->\n\t<link href="../css/custom.css" rel="stylesheet">\n\n\n</head>\n\n<body>\n\n\t<!-- jQuery -->\n\t<script src="../js/jquery.js"></script>\n\t<script src="../js/bootstrap.min.js"></script>\n\t<script src="../js/changePassword.js"></script>\n\n\t<div class="body_div">\n\n\t\t\t<!-- header file containing the main nav bar and logo -->\n\t\t\t')
        # SOURCE LINE 31
        runtime._include_file(context, u'../header.mako', _template_uri)
        __M_writer(u'\n\n\t\t\t<div class="row">\n\t\t\t\t<div id="sidebar" style="display: none;" class="col-sm-2">\n\t\t\t\t\t')
        # SOURCE LINE 35
        runtime._include_file(context, u'../tools/sidebar.mako', _template_uri)
        __M_writer(u'\n\t\t\t\t</div>\n\n\t\t\t\t<div id="mainContent" class="col-sm-10">\n\t\t\t\t\t\n\t\t\t\t\t<div id="newAccount" class="wellA">\n\t\t\t\t\t<h2 class="form" id="pageheader"><br></h2>\n\t\t\t\t\t\t<div><h4 class="formA" id = "changepw"></h4></div><br>\n\n\t\t\t\t\t\t<div class="form-group">\n\t\t\t\t\t\t\t<div class="row">\n\t\t\t\t\t\t\t\t<div class="col-A">\n\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Current Password</span>\n\t\t\t\t\t\t\t\t\t\t<input id="old_password" type="text" class="form-controlA" placeholder="John" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">New Password</span>\n\t\t\t\t\t\t\t\t\t\t<input id="new_password" type="text" class="form-controlA" placeholder="Doe" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">New Password</span>\n\t\t\t\t\t\t\t\t\t\t<input id="new_password_confirm" type="text" class="form-controlA" placeholder="john.doe@example.com" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t<br>\n\t\t\t\t\t\t\t\t\t<input id="submit" type="submit" class="button_general_left">\n\t\t\t\t\t\t\t</div> <!-- close row -->\n\n\t\t\t\t\t\t\t<!-- This is used to store the original email address if the user is being edited-->\n\t\t\t\t\t\t\t<div style="display: none;">\n\t\t\t\t\t\t\t\t<input id="orderID" type="text" class="form-control" val="">\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div> <!-- close form group -->\n\t\t\t\t\t</div> <!-- close well -->\n\n\t\t\t\t</div> <!-- close main content -->\n\t\t\t</div>\n\t\t\t\n\t\t\t')
        # SOURCE LINE 76
        runtime._include_file(context, u'../footer.mako', _template_uri)
        __M_writer(u'\n\t\t</div><!--End of body_div-->\n\n\t</body>\n\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


