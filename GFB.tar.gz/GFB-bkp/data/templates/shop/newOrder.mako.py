# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 9
_modified_time = 1425165877.536194
_enable_loop = True
_template_filename = '/home/edgard/eclipse-workspaces/gfb/GFB/gardenfreshbox/templates/shop/newOrder.mako'
_template_uri = '/shop/newOrder.mako'
_source_encoding = 'utf-8'
from webhelpers.html import escape
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(u'<!DOCTYPE html>\n<html lang="en">\n\n<head>\n\t<meta charset="utf-8">\n\t<meta http-equiv="X-UA-Compatible" content="IE=edge">\n\t<meta name="viewport" content="width=device-width, initial-scale=1">\n\t<meta name="description" content="Garden Fresh Box">\n\t<meta name="author" content="Fruitful Community Solutions">\n\n\t<title>Garden Fresh Box</title>\n\n\t<!-- Bootstrap Core CSS -->\n\t<link href="../css/bootstrap.min.css" rel="stylesheet">\n\n\t<!-- Custom CSS -->\n\t<link href="../css/custom.css" rel="stylesheet">\n</head>\n\n<body>\n\n\t<!-- jQuery -->\n\t<script src="../js/jquery.js"></script>\n\n\t<!-- Bootstrap Core JavaScript -->\n\t<script src="../js/bootstrap.min.js"></script>\n\t\n\t<!-- Helper JavaScript -->\n\t<script src="../js/helper.js"></script>\n\t\n\t<!-- New Order Custom JavaScript -->\n\t<script src="../js/newOrder.js"></script>\n\n\t<div class="body_div">\n\n\t\t\t<!-- header file containing the main nav bar and logo -->\n\t\t\t')
        # SOURCE LINE 37
        runtime._include_file(context, u'../header.mako', _template_uri)
        __M_writer(u'\n\t\t\t\n\t\t\t<div class="row">\n\t\t\t\t<div id="sidebar" style="display: none;" class="col-sm-2">\n\t\t\t\t\t')
        # SOURCE LINE 41
        runtime._include_file(context, u'../tools/sidebar.mako', _template_uri)
        __M_writer(u'\n\t\t\t\t</div>\n\n\t\t\t\t<div id="mainContent" class="col-sm-10">\n\t\t\t\t\t<div id="newAccount" class="wellA">\n\n\t\t\t\t\t\t<div id = "hsAction"><h4 class="form">New Order</h4></div><br>\n\n\t\t\t\t\t\t<div class="form-group">\n\t\t\t\t\t\t\t<div class="row">\n\t\t\t\t\t\t\t\t<div class="col-A">\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">First Name</span>\n\t\t\t\t\t\t\t\t\t\t<input id="customer_first_name" type="text" class="form-controlA" placeholder="John" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Last Name</span>\n\t\t\t\t\t\t\t\t\t\t<input id="customer_last_name" type="text" class="form-controlA" placeholder="Doe" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Email</span>\n\t\t\t\t\t\t\t\t\t\t<input id="customer_email" type="text" class="form-controlA" placeholder="john.doe@example.com" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Phone</span>\n\t\t\t\t\t\t\t\t\t\t<input id="customer_phone" type="text" class="form-controlA" placeholder="519-123-4567" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group text-left">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group">\n\t\t\t\t\t\t\t\t\t\t<p><br>Recieve Email notifications?   \n\t\t\t\t\t\t\t\t\t\t\t<input id="email_notifications" type="checkbox" value="off" onchange="toggleEmail()">\n\t\t\t\t\t\t\t\t\t\t</p>\n\t\t\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span>Date</span>\n\t\t\t\t\t\t\t\t\t\t<input id="creation_date" type="text" class="form-control" placeholder="" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<br>\n\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t</div>\n\t\n\t\t\t\t\t\t\t\t<div class="col-A">\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA2">Pickup Location and Date</span>\n\t\t\t\t\t\t\t\t\t\t<select id="hostsitepickup_idFK" class="form-controlB"></select>\n\t\t\t\t\t\t\t\t\t\t<select id="distribution_date" class="form-controlB">\n\t\t\t\t\t\t\t\t\t\t\t<option>11/19/2014</option>\n\t\t\t\t\t\t\t\t\t\t\t<option>12/17/2014</option>\n\t\t\t\t\t\t\t\t\t\t\t<option>1/21/2015</option>\n\t\t\t\t\t\t\t\t\t\t\t<option>2/18/2015</option>\n\t\t\t\t\t\t\t\t\t\t\t<option>3/18/2015</option>\n\t\t\t\t\t\t\t\t\t\t\t<option>4/15/2015</option>\n\t\t\t\t\t\t\t\t\t\t\t<option>5/20/2015</option>\n\t\t\t\t\t\t\t\t\t\t</select>\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Number Small</span>\n\t\t\t\t\t\t\t\t\t\t<input id="small_quantity" type="text" class="form-controlA" placeholder="0" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Number Large</span>\n\t\t\t\t\t\t\t\t\t\t<input id="large_quantity" type="text" class="form-controlA" placeholder="0" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Amt. Paid</span>\n\t\t\t\t\t\t\t\t\t\t<input id="total_paid" type="text" class="form-controlA" placeholder="0" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Donation Amt.</span>\n\t\t\t\t\t\t\t\t\t\t<input id="donation" type="text" class="form-controlA" placeholder="0" val="">\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="input-group text-left">\n\t\t\t\t\t\t\t\t\t\t<span class="input-group">\n\t\t\t\t\t\t\t\t\t\t<p><br>Receive Donation Receipt?   \n\t\t\t\t\t\t\t\t\t\t\t<input id="donation_receipt" type="checkbox" value="off" onchange="toggleReceipt()">\n\t\t\t\t\t\t\t\t\t\t</p>\n\t\t\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<input id="submit" type="submit" class="button_general_left">\n\t\t\t\t\t\t\t</div> <!-- close row -->\n\t\t\t\t\t\t\n\t\t\t\t\t\t\t<!-- This is used to store the original email address if the user is being edited-->\n\t\t\t\t\t\t\t<div style="display: none;">\n\t\t\t\t\t\t\t\t<input id="orderID" type="text" class="form-control" val="">\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div> <!-- close form group -->\n\t\t\t\t\t</div> <!-- close well -->\n\t\t\t\t</div> <!-- close main content -->\n\t\t\t</div>\n\n\t\t\t')
        # SOURCE LINE 133
        runtime._include_file(context, u'../footer.mako', _template_uri)
        __M_writer(u'\n\n\t\t</div><!--End of body_div-->\n\t</body>\n\n</html>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


