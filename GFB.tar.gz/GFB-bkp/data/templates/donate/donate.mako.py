# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 9
_modified_time = 1425165674.76323
_enable_loop = True
_template_filename = '/home/edgard/eclipse-workspaces/gfb/GFB/gardenfreshbox/templates/donate/donate.mako'
_template_uri = '/donate/donate.mako'
_source_encoding = 'utf-8'
from webhelpers.html import escape
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(u'<!DOCTYPE html>\n<html lang="en">\n\n\t<head>\n\t\t<meta charset="utf-8">\n\t\t<meta http-equiv="X-UA-Compatible" content="IE=edge">\n\t\t<meta name="viewport" content="width=device-width, initial-scale=1">\n\t\t<meta name="description" content="Garden Fresh Box">\n\t\t<meta name="author" content="Fruitful Community Solutions">\n\n\t\t<title>Garden Fresh Box - Donate</title>\n\n\t\t<!-- Bootstrap Core CSS -->\n\t\t<link href="../css/bootstrap.min.css" rel="stylesheet">\n\n\t\t<!-- Custom CSS -->\n\t\t<link href="../css/custom.css" rel="stylesheet">\n\t</head>\n\n\t<body>\n\n\t\t<!-- jQuery -->\n\t\t<script src="js/jquery.js"></script>\n\n\t\t<!-- Bootstrap Core JavaScript -->\n\t\t<script src="js/bootstrap.min.js"></script>\n\n\t\t<!-- Helper Custom JavaScript -->\n\t\t<script src="js/helper.js"></script>\n\n\t\t<!-- Donate Custom JavaScript -->\n\t\t<script src="js/donate.js"></script>\n\n\t\t<div class="body_div">\n\n\t\t\t<!-- header file containing the main nav bar and logo -->\n\t\t\t')
        # SOURCE LINE 37
        runtime._include_file(context, u'../header.mako', _template_uri)
        __M_writer(u'\n\t\t\t<div class="row">\n\t\t\t\t<div id="sidebar" style="display: none;" class="col-sm-2">\n\t\t\t\t\t')
        # SOURCE LINE 40
        runtime._include_file(context, u'../tools/sidebar.mako', _template_uri)
        __M_writer(u'\n\t\t\t\t</div>\n\n\t\t\t\t<div id="mainContent" class="col-sm-10">\n\t\t\t\t\t\n\t\t\t\t\t<div id="newAccount" class="wellA">\n\n\t\t\t\t\t<div id = "hsAction"><h4 class="form">New Donation</h4></div><br>\n\t\t\t\t\t<div class="form-group">\n\t\t\t\t\t\t<div class="row">\n\t\t\t\t\t\t\t<div class="col-A">\n\t\t\t\t\t\t\t\t<h5 class="formA"> Contact Information </h5>\n\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">First Name</span>\n\t\t\t\t\t\t\t\t\t<input id="customer_first_name" type="text" class="form-controlA" placeholder="John" val="">\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Last Name</span>\n\t\t\t\t\t\t\t\t\t<input id="customer_last_name" type="text" class="form-controlA" placeholder="Doe" val="">\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Email Address</span>\n\t\t\t\t\t\t\t\t\t<input id="customer_email" type="text" class="form-controlA" placeholder="john.doe@example.com" val="">\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Phone Number</span>\n\t\t\t\t\t\t\t\t\t<input id="phone" type="text" class="form-controlA" placeholder="519-123-4567" val="">\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<div class="col-A">\n\t\t\t\t\t\t\t\t<h5 class="formA"> Donation Order </h5>\n\t\t\t\t\t\t\t\t<div class="input-group">\n\t\t\t\t\t\t\t\t\t<span class="input-group-addonA">Donation Amount</span>\n\t\t\t\t\t\t\t\t\t<input id="donation" type="text" class="form-controlA" placeholder="20" val="">\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class="input-group text-left">\n\t\t\t\t\t\t\t\t\t<span class="input-group">\n\t\t\t\t\t\t\t\t\t\t<p><br>\n\t\t\t\t\t\t\t\t\t\t\tReceive Donation Receipt?   \n\t\t\t\t\t\t\t\t\t\t\t<input id="donation_receipt" type="checkbox" value="off" onchange="toggleReceipt()">\n\t\t\t\t\t\t\t\t\t\t</p>\n\t\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t\t</div>\n\n\t\t\t\t\t\t\t\t<br>\n\t\t\t\t\t\t\t\t<br>\n\t\t\t\t\t\t\t\t<br>\n\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<input id="confirmDonate" type="submit" class="button_general_left">\n\t\t\t\t\t\t</div>\n\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\t\n\n\t\t\t')
        # SOURCE LINE 97
        runtime._include_file(context, u'../footer.mako', _template_uri)
        __M_writer(u'\n\n\t\t</div><!--End of body_div-->\n\n\n\t</body>\n\n</html>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


