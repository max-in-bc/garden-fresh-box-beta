# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 9
_modified_time = 1425065703.855355
_enable_loop = True
_template_filename = u'/home/edgard/eclipse-workspaces/gfb/GFB/gardenfreshbox/templates/footer.mako'
_template_uri = u'/footer.mako'
_source_encoding = 'utf-8'
from webhelpers.html import escape
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(u'<div class="footer">\n\n\t<div class="footer_main">\n\n\t\t<div class="footer_contact">\n\t\t\t<div class="contact_us_heading">\n\t\t\t\t<h2 class="contact_us_heading">\n\t\t\t\t\tContact Us:\n\t\t\t\t</h2>\n\t\t\t</div>\n\t\t\t<div class="contact_us_info">\n\t\t\t\t<p class="contact_us">\n\t\t\t\t\tPhone: (519) 821-6638 ext. 344<br>\n\t\t\t\t\tEmail: <a href="mailto:gfbox@guelphchc.ca?Subject=Garden%20Fresh%20Box%20Feedback" target="_top">gfbox@guelphchc.ca</a><br>\n\t\t\t\t\tMailing: 176 Wyndham St. N, Guelph, ON, N1H 8N9\n\t\t\t\t\t<br>\n\t\t\t\t</p>\n\t\t\t</div>\n\t\t</div>\n\n\t\t<div id="login" class="footer_login">\n\t\t\t<a href="/login" class="footer_login">\n\t\t\t\t<!-- <button class="btn btn-default">Login</button> -->\n\t\t\t\tLogin\n\t\t\t</a>\n\t\t</div>\n\n\t\t<div id="logout" class="footer_login">\n\t\t\t<a class="footer_login" id="logout_button" style="cursor:pointer;"> Logout </a>\n\t\t</div>\n\t</div>\n\n\t<div class="footer_images">\n\t\t<a href="http://www.guelphchc.ca/" target="_blank"><img src="../images/GuelphCHCLogo.png" class="footer_images"></a>\n\t\t<a href="http://www.children.gov.on.ca/" target="_blank"><img src="../images/MinistryOfChildrenAndYouthServices.png" class="footer_images"></a>\n\t\t<a href="http://www.waterloowellingtonlhin.on.ca/" target="_blank"><img src="../images/WaterlooWellingtonLocalHealthNetwork.png" class="footer_images"></a>\n\t\t<a href="http://www.ontariochc.org/" target="_blank"><img src="../images/OntarioCommunityHealth.png" class="footer_images"></a>\n\t</div>\n\n\t<script type="text/javascript">\n\t\t//get user information to see if they are logged in\n\t\t$(window).load(function(){\n\t\t\t$.get(\'/user/me\', {}, function(response){\n\t\t\t\tif(response==\'\'){\n\t\t\t\t\t//user is not logged in, ensure login is available\n\t\t\t\t\tvar e = document.getElementById(\'login\');\n\t\t\t\t\te.style.display = \'footer_login\';\n\t\t\t\t\tvar e = document.getElementById(\'logout_button\');\n\t\t\t\t\te.style.display = \'none\';\n\t\t\t\t} else{\n\t\t\t\t\tvar me = JSON.parse(response);\n\t\t\t\t\tvar e = document.getElementById(\'login\');\n\t\t\t\t\te.style.display = \'none\';\n\t\t\t\t\tvar e = document.getElementById(\'logout\');\n\t\t\t\t\te.style.display = \'footer_login\';\n\t\t\t\t}\n\t\t\t});\n\t\t});\n\n\t\t$("#logout_button").click(function(e){\n\t\t\t$.get(\'/user/logout\', {}, function(response){\n\t\t\t\talert("You have been logged out.");\n\t\t\t\twindow.location.href = \'/\';\n\t\t\t});\n\t\t});\n\t</script>\n\n</div>')
        return ''
    finally:
        context.caller_stack._pop_frame()


