# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 9
_modified_time = 1425065703.846319
_enable_loop = True
_template_filename = '/home/edgard/eclipse-workspaces/gfb/GFB/gardenfreshbox/templates/index.mako'
_template_uri = '/index.mako'
_source_encoding = 'utf-8'
from webhelpers.html import escape
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(u'<!DOCTYPE html>\n<html lang="en">\n\n\t<head>\n\t\t<meta charset="utf-8">\n\t\t<meta http-equiv="X-UA-Compatible" content="IE=edge">\n\t\t<meta name="viewport" content="width=device-width, initial-scale=1">\n\t\t<meta name="description" content="Garden Fresh Box">\n\t\t<meta name="author" content="Fruitful Community Solutions">\n\n\t\t<title>Garden Fresh Box</title>\n\n\t\t<!-- Bootstrap Core CSS -->\n\t\t<link href="css/bootstrap.min.css" rel="stylesheet">\n\n\t\t<!-- Custom CSS -->\n\t\t<link href="css/custom.css" rel="stylesheet">\n\t</head>\n\n\t<body>\n\t\t<!-- jQuery -->\n\t\t<script src="js/jquery.js"></script>\n\t\t<!-- Bootstrap Core JavaScript -->\n\t\t<script src="js/bootstrap.min.js"></script>\n\n\t\t<div class="row">\n\t\t\t<div class="body_div">\n\t\t\t\t<!-- header file containing the main nav bar and logo -->\n\t\t\t\t')
        # SOURCE LINE 29
        runtime._include_file(context, u'header.mako', _template_uri)
        __M_writer(u'\n\t\t\t\t<div id="sidebar" style="display: none;" class="col-sm-2">\n\t\t\t\t\t')
        # SOURCE LINE 31
        runtime._include_file(context, u'/tools/sidebar.mako', _template_uri)
        __M_writer(u'\n\t\t\t\t</div>\n\n\t\t\t\t<div id="mainContent" class="col-sm-10">\n\t\t\t\t\t<div class="content">\n\t\t\t\t\t\t<!-- <div><h1>HomePage</h1></div> -->\n\t\t\t\t\t\t<div class="summary_buttons">\n\t\t\t\t\t\t\t<div class="summary_end">\n\t\t\t\t\t\t\t\t<a href="/shop/buy">\n\t\t\t\t\t\t\t\t\t<div class="summary_button" id="summary_buy_garden_fresh_box">\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t<div class="summary_heading">\n\t\t\t\t\t\t\t\t\t\t\t<h2 class="summary_button">\n\t\t\t\t\t\t\t\t\t\t\t\tBuy a Garden Fresh Box\n\t\t\t\t\t\t\t\t\t\t\t</h2>\n\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t\t\t<div class="summary_description">\n\t\t\t\t\t\t\t\t\t<p class="summary_button">\n\t\t\t\t\t\t\t\t\t\tShop for a Garden Fresh Box for yourself or your family.\n\t\t\t\t\t\t\t\t\t\t<br>\n\t\t\t\t\t\t\t\t\t\t<a href="/shop/buy">\n\t\t\t\t\t\t\t\t\t\tLearn More\n\t\t\t\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t\t\t\t</p>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t</div>\n\n\t\t\t\t\t\t\t<div class="summary_mid">\n\t\t\t\t\t\t\t\t<a href="/info">\n\t\t\t\t\t\t\t\t\t<div class="summary_button" id="summary_about_garden_fresh_box">\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t<div class="summary_heading">\n\t\t\t\t\t\t\t\t\t\t\t<h2 class="summary_button">\n\t\t\t\t\t\t\t\t\t\t\t\tAbout the Program\n\t\t\t\t\t\t\t\t\t\t\t</h2>\n\t\t\t\t\t\t\t\t\t\t</div>\t\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t\t\t<div class="summary_description">\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t<p class="summary_button">\n\t\t\t\t\t\t\t\t\t\tLearn more about the Garden Fresh Box Program and how we\'re helping Guelph.\n\t\t\t\t\t\t\t\t\t\t<br>\n\t\t\t\t\t\t\t\t\t\t<a href="/info">\n\t\t\t\t\t\t\t\t\t\t\tLearn More\n\t\t\t\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t\t\t\t</p>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t</div>\n\n\t\t\t\t\t\t\t<div class="summary_end">\n\t\t\t\t\t\t\t\t<a href="/contact">\n\t\t\t\t\t\t\t\t\t<div class="summary_button" id="summary_feedback_image">\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t<div class="summary_heading">\n\t\t\t\t\t\t\t\t\t\t\t<h2 class="summary_button">\n\t\t\t\t\t\t\t\t\t\t\t\tLeave Feedback\n\t\t\t\t\t\t\t\t\t\t\t</h2>\n\t\t\t\t\t\t\t\t\t\t</div>\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t\t\t<div class="summary_description">\n\t\t\t\t\t\t\t\t\t<p class="summary_button">\n\t\t\t\t\t\t\t\t\t\tAre we doing a good job? Let the community know by leaving some feedback!\n\t\t\t\t\t\t\t\t\t\t<br>\n\t\t\t\t\t\t\t\t\t\t<a href="/contact">\n\t\t\t\t\t\t\t\t\t\t\tLearn More\n\t\t\t\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t\t\t\t</p>\n\t\t\t\t\t\t\t\t</div>\t\t\t\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div><!-- End of summary buttons -->\n\t\t\t\t\t</div><!-- End of the content div -->\n\t\t\t\t</div>\n\t\t\t\t')
        # SOURCE LINE 103
        runtime._include_file(context, u'footer.mako', _template_uri)
        __M_writer(u'\n\t\t\t</div> <!-- end of body div-->\n\t\t</div> <!-- end of row -->\n\n\n\t</body>\n\n</html>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


