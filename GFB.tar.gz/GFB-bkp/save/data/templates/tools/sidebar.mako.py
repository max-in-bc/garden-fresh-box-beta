# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 9
_modified_time = 1425065703.853251
_enable_loop = True
_template_filename = u'/home/edgard/eclipse-workspaces/gfb/GFB/gardenfreshbox/templates/tools/sidebar.mako'
_template_uri = u'/tools/sidebar.mako'
_source_encoding = 'utf-8'
from webhelpers.html import escape
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(u'<nav>\n\t<div class="sidebar-nav navbar-left" role ="navigation">\n\t\n\t\t<div id="user-controls">\n\t\t\t<h4>User Tools</h4>\n\t\t\t<ul class="nav nav-pills nav-stacked">\n\t\t\t\t<li id="changepassword" class="" role="presentation"><a href="/cashsales">Change Password</a></li>\n\t\t\t\t<li id="editinfo" class="" role="presentation"><a href="/distribution">Edit Personal Infomation</a></li>\n\t\t\t</ul>\n\n\t\t\t<div id="hostsite-controls">\n\t\t\t\t<h4>Host Site Tools</h4>\n\t\t\t\t<ul class="nav nav-pills nav-stacked">\n\t\t\t\t\t<li id="cashsales" class="" role="presentation"><a href="/cashsales">Cash Sales</a></li>\n\t\t\t\t\t<li id="distOrders" class="" role="presentation"><a href="/distribution">Orders to Distribute</a></li>\n\t\t\t\t</ul>\n\t\t\t\n\t\t\t\t\t<div id="admin-controls">\n\t\t\t\t\t\t<h4>Administrator Tools</h4>\n\t\t\t\t\t\t<ul class="nav nav-pills nav-stacked">\n\t\t\t\t\t\t\t<li id="hostsites" class="" role="presentation"><a href="/hostsites">Manage Host Sites</a></li>\n\t\t\t\t\t\t\t<li id="accounts" class="" role="presentation"><a href="/accounts">Manage Accounts</a></li>\n\t\t\t\t\t\t\t<li id="masterorders" class="" role="presentation"><a href="/masterorders">Master Order List</a></li>\n\t\t\t\t\t\t\t<li id="donors" class="" role="presentation"><a href="/donors">Master Donation List</a></li>\n\t\t\t\t\t\t\t<li id="mastercustomers" class="" role="presentation"><a href="/mastercustomers">Master Customer List</a></li>\n\t\t\t\t\t\t</ul>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t</div>\n</nav>\n\n<script type="text/javascript">\n\t$(window).load(function(){\n\t\tvar e = document.getElementById(\'sidebar\');\n\t\t$.get(\'/user/me\', {}, function(response){\n\t\t\tif(response==\'\'){\n\t\t\t\t//user is not logged in\n\t\t\t\te.style.display = \'none\';\n\t\t\t\tdocument.getElementById(\'mainContent\').className=\'col-sm-12\';\n\t\t\t} else{\n\t\t\t\te.style.display = \'block\';\n\t\t\t\tdocument.getElementById(\'mainContent\').className=\'col-sm-10\';\n\t\t\t\t\n\t\t\t\tvar me = JSON.parse(response);\n\t\t\t\t\n\t\t\t\tif(me.role == 3){\n\t\t\t\t\tvar role = document.getElementById(\'admin-controls\');\n\t\t\t\t\trole.style.display = \'none\';\n\t\t\t\t\tdocument.getElementById(\'mainContent\').className=\'col-sm-12\';\n\t\t\t\t\t\n\t\t\t\t\trole = document.getElementById(\'hostsite-controls\');\n\t\t\t\t\trole.style.display = \'block\';\n\t\t\t\t\tdocument.getElementById(\'mainContent\').className=\'col-sm-10\';\n\t\t\t\t} \n\t\t\t\telse if(me.role == 4){\n\t\t\t\t\tvar role = document.getElementById(\'hostsite-controls\');\n\t\t\t\t\trole.style.display = \'none\';\n\t\t\t\t\tdocument.getElementById(\'mainContent\').className=\'col-sm-12\';\n\t\t\t\t\t\n\t\t\t\t\trole = document.getElementById(\'user-controls\');\n\t\t\t\t\trole.style.display = \'block\';\n\t\t\t\t\tdocument.getElementById(\'mainContent\').className=\'col-sm-10\';\n\t\t\t\t} \n\t\t\t}\n\t\t});\n\n\t\tvar curr = /[^/]*$/.exec(window.location.href)[0];\n\n\t\tvar ele = document.getElementById(curr.valueOf());\n\n\t\tif (ele != null){\n\t\t\tele.className=\'active\';\n\t\t}\n\n\t});\n</script>')
        return ''
    finally:
        context.caller_stack._pop_frame()


