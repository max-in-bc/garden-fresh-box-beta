# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 9
_modified_time = 1425065703.85115
_enable_loop = True
_template_filename = u'/home/edgard/eclipse-workspaces/gfb/GFB/gardenfreshbox/templates/header.mako'
_template_uri = u'/header.mako'
_source_encoding = 'utf-8'
from webhelpers.html import escape
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(u'<div class="header">\n\t<div class="logo_image">\n\t\t<a href="/">\n\t\t\t<img src="../images/BannerImage.jpg">\n\t\t</a>\n\t</div>\n\t<div class="regular_nav">\n\t\t<ul class="regular_nav">\n\t\t\t<li class="regular_nav">\n\t\t\t\t<a href="/">Home</a>\n\t\t\t</li>\n\t\t\t<li class="regular_nav">\n\t\t\t\t<a href="/info">Info</a>\n\t\t\t</li>\n\t\t\t<li class="regular_nav">\n\t\t\t\t<a href="/shop/buy">Buy</a>\n\t\t\t</li>\n\t\t\t<li class="regular_nav">\n\t\t\t\t<a href="/donate">Donate</a>\n\t\t\t</li>\n\t\t\t<li class="regular_nav">\n\t\t\t\t<a href="/contact">Contact Us</a>\n\t\t\t</li>\n\t\t</ul>\n\t\t<p id="name" class="text-right" style="height:10px;margin-top:10px;margin-right:20px;"></p>\n\t</div>\n</div>\n\n<script type="text/javascript">\n\t//get user information to see if they are logged in\n\t$(window).load(function(){\n\t\t$.get(\'/user/me\', {}, function(response){\n\t\t\tif(response==\'\'){\n\t\t\t\t$("#name").html("");\n\t\t\t} else{\n\t\t\t\tvar me = JSON.parse(response);\n\t\t\t\t//me.user_name = the user\'s email address\n\t\t\t\tvar e = document.getElementById(\'name\');\t\n\t\t\t\t$("#name").html("Hello " + me.user_name);\n\t\t\t}\n\t\t});\n\t});\n</script>')
        return ''
    finally:
        context.caller_stack._pop_frame()


