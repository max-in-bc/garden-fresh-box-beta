python setup.py develop
paster serve --reload development.ini

